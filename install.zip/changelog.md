### v1.0 - 27.10.2023
* Initial release