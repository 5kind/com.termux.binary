# remove build scripts
rm $MODPATH/{check-system-binary,make-module,update-binary}.sh